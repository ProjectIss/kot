﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.OleDb;
using System.Data;
using System.IO;
using static RestarentService.Comman;

namespace RestarentService.Controllers
{

    [RoutePrefix("_/Api/KODController")]

    public class KODController : ApiController
    {
        //ExcelHandler objKODController = new ExcelHandler();
        Comman.Connection connection = new Comman.Connection();
        private object dataTable;

        [Route("connectionstring")]
        [HttpGet]
       
        public DataTable ConnectionString()
        {
            HandlerAccess obj = new HandlerAccess();

            DataTable data = obj.ExecuteTable("Select * from Itemsetup", "Itemsetup");
            //connection.ToCsv(data, sbData);
          //  connection.ToCsv(data);

            string CSV = connection.ToCsv(data);
            string fileName = "KOD" + DateTime.Now.ToString("ddMMyyhhmm") + ".csv";
            string filePath = System.Web.Hosting.HostingEnvironment.MapPath("~/Orders/xls/") + fileName;
            if (!File.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(System.Web.Hosting.HostingEnvironment.MapPath("~/Orders/xls"));
            }
            File.WriteAllText(filePath, CSV);
            
            return data;

        }

        [Route("Cnnctnstring")]
        [HttpGet]
        public DataTable Cnnctnstring()
        {
            string sbData = @"C:\CSV";
            HandlerAccess obj = new HandlerAccess();

            DataTable data = obj.ExecuteTable("Select * from TblTable", "TblTable");
            connection.ToCsv(data);

            return data;

        }

        [Route("cntnstrng")]
        [HttpGet]
        public DataTable cntnstrng()
        {
            string sbData = @"C:\CSV";
            HandlerAccess obj = new HandlerAccess();

            DataTable data = obj.ExecuteTable("Select * from TblWaiter", "TblWaiter");
            connection.ToCsv(data);

            return data;

        }

    }
}
